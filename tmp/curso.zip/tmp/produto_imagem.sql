INSERT INTO produto_imagem (id,produto_id,imagem) VALUES (1,1,'files/imagems/1/libreoffice-oasis-text-template.png');
INSERT INTO produto_imagem (id,produto_id,imagem) VALUES (2,1,'files/imagems/1/libreoffice-oasis-web-template.png');
