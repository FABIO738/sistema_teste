INSERT INTO produto (id,descricao,estoque,preco_venda,unidade,local_foto) VALUES (1,'PNEU RECAPADO BORRACHUDO',10,1750,'UN','');
INSERT INTO produto (id,descricao,estoque,preco_venda,unidade,local_foto) VALUES (2,'PNEU RECAPADO LISO ',10,1350,'UN','');
INSERT INTO produto (id,descricao,estoque,preco_venda,unidade,local_foto) VALUES (3,'CONSERTO SIMPLES',100,150,'UN','');
INSERT INTO produto (id,descricao,estoque,preco_venda,unidade,local_foto) VALUES (4,'CONSERTO ENCHIMENTO',150,180,'UN','');
