INSERT INTO categoria (id,nome) VALUES (1,'Frequente');
INSERT INTO categoria (id,nome) VALUES (2,'Casual');
INSERT INTO categoria (id,nome) VALUES (3,'Varejista');
