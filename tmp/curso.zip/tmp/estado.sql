INSERT INTO estado (id,nome) VALUES (1,'RS');
INSERT INTO estado (id,nome) VALUES (2,'SP');
INSERT INTO estado (id,nome) VALUES (3,'MT');
INSERT INTO estado (id,nome) VALUES (4,'MS');
