INSERT INTO habilidade (id,nome) VALUES (1,'Leitura');
INSERT INTO habilidade (id,nome) VALUES (2,'Escrita');
INSERT INTO habilidade (id,nome) VALUES (3,'Comunicação');
INSERT INTO habilidade (id,nome) VALUES (4,'Criatividade');
INSERT INTO habilidade (id,nome) VALUES (5,'Relações');
INSERT INTO habilidade (id,nome) VALUES (6,'Organização');
INSERT INTO habilidade (id,nome) VALUES (7,'Liderança');
